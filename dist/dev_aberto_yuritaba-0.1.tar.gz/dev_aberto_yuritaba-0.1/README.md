# Dev Aberto

Este pacote fornece funcionalidades úteis para desenvolvedores em Python, incluindo a função `hello` que exibe uma saudação personalizada.

[Repositório da Disciplina](https://github.com/insper/open-dev)